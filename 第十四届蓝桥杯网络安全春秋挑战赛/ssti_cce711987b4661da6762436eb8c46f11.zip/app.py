import uuid

from flask import Flask, render_template, redirect, url_for, request, session, abort, flash, render_template_string

app = Flask(__name__)

numbers_str = [str(x) for x in range(10)]
black_list = ["class", "__", "'", "\"", "~", "+", "globals", "request", "{%", "true", "false", 'lipsum', 'url_for',
              'get_flashed_messages', 'range', 'dict', 'cycler', 'self']
black_list += numbers_str

app.config.update(dict(
    SECRET_KEY=str(uuid.uuid4()),
))


def waf(name):
    for x in black_list:
        if x in name.lower():
            return True
    return False


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/user')
def user():
    name = request.args.get("username")
    if waf(name):
        return "No hacker"
    return render_template_string(name)


if __name__ == '__main__':
    app.run("0.0.0.0", port=8888)
